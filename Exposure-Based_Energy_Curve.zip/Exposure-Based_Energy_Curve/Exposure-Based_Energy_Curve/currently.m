clc
clear all
close all

% Select the folder containing the dataset of images
folderPath = uigetdir('','Select the folder containing the dataset');
fileList = dir(fullfile(folderPath, '*.jpg')); % assuming all images are in jpg format
numImages = numel(fileList);

for k = 1:numImages
    % Read the k-th image from the dataset
    imageName = fileList(k).name;
    imagePath = fullfile(folderPath, imageName);
    I = imread(imagePath);

    % Display the current input image
    subplot(3, 4, k);
    imshow(I);
    title(['Image ', num2str(k)]);

    % Convert to grayscale if necessary
    if size(I, 3) == 3
        img = rgb2gray(I);
    else
        img = I;
    end

    % Define the threshold value 'l'
    l = 128; % Assuming a threshold value for illustration

    % Define the neighborhood size
    neighborhood_size = 3; % Assuming a 3x3 neighborhood for illustration

    % Initialize the energy curve matrix
    energyCurve = zeros(size(img));

    % Compute the energy curve for each pixel
    for i = 1:size(img, 1)
        for j = 1:size(img, 2)
            energy = 0;
            for u = -1:1
                for v = -1:1
                    if i+u > 0 && i+u <= size(img, 1) && j+v > 0 && j+v <= size(img, 2)
                        % Compute B_ij and B_pq based on the condition I_ij > l
                        b_ij = img(i, j) > l;
                        b_pq = img(i+u, j+v) > l;
                        c_ij = 1; % Assuming a constant value for c_ij
                        c_pq = 1; % Assuming a constant value for c_pq
                        energy = energy + b_ij * b_pq + c_ij * c_pq;
                    end
                end
            end
            energyCurve(i, j) = energy;
        end
    end

    % Compute exposure parameter value
    L = numel(energyCurve);
    weighted_sum = sum(energyCurve(:) .* (0:L-1)');
    sum_energy = sum(energyCurve(:));
    exposure = 1 / L * (weighted_sum / sum_energy);

    % Display the exposure threshold
    disp(['Exposure threshold for Image ', num2str(k), ': ', num2str(exposure)]);

    % Separate the color channels
    if size(I, 3) == 3
        redPlane = I(:,:,1);
        greenPlane = I(:, :, 2);
        bluePlane = I(:, :, 3);
    else
        error(['Input image ', num2str(k), ' is not in RGB format']);
    end

    % Calculate histograms for each channel
    histRed = imhist(redPlane);
    histGreen = imhist(greenPlane);
    histBlue = imhist(bluePlane);

    % Plot the histograms
    subplot(3, 4, k + 4);
    plot(histRed, 'r');hold on
    plot(histGreen, 'g');hold on
    plot(histBlue, 'b');hold off
    title(['Histogram for Image ', num2str(k)]);

    % Compute energy curve for each channel
    energyCurve1 = zeros(256, 3);
    energyCurve2 = zeros(256, 3);
    for channel = 1:3
        [counts, ~] = imhist(I(:, :, channel));
        energyCurve = cumsum(counts) / sum(counts);

        % Calculate exposure threshold for each channel
        L = 256; % Number of intensity levels
        ET = round((L - 1) * (1 - exposure)); % Round to the nearest integer

        % Divide energy curve in two parts using calculated threshold for each channel
        energyCurve1(1:ET, channel) = energyCurve(1:ET);
        energyCurve2(ET+1:L-1, channel) = (energyCurve(ET+1:L-1));

        % Compute PDF and CDF for lower and upper regions
        PDF_L = energyCurve1(:, channel) / sum(energyCurve1(:, channel));
        PDF_U = energyCurve2(:, channel) / sum(energyCurve2(:, channel));
        CDF_L = cumsum(PDF_L);
        CDF_U = cumsum(PDF_U);

        % Generate transformation function for lower curve
        T_L = ET * CDF_L;

        % Generate transformation function for upper curve
        T_U = (ET + 1) + (L - (ET + 1)) * CDF_U;

        % Final transformation function
        transferFunction = T_L + T_U;

        % Apply the transfer function to the input channel
        enhancedChannel = histeq(imadjust(I(:, :, channel)), transferFunction); % Adjust histogram equalization parameters

        % Store the enhanced channel
        enhancedImage(:, :, channel) = enhancedChannel;
    end

    % Display the enhanced image
    subplot(3, 4, k + 8);
    imshow(imsharpen(uint8(enhancedImage)));
    title(['Enhanced Image ', num2str(k)]);
end
