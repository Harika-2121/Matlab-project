clc
clear all
close all

% select the image with low contrast
[J, P] = uigetfile('*.*', 'Select the image');
I = imread(fullfile(P, J));
subplot(323), imshow(I), title('Input Image');

% Check if the image is grayscale, if not, convert it to grayscale
if size(I, 3) == 3
    I_gray = rgb2gray(I);
else
    I_gray = I;
end

subplot(324), imshow(I_gray), title('Grayscale Image');

% Calculate the local energy map using a 3x3 neighborhood
neighborhood_size = 3;
energy_map = conv2(double(I_gray).^2, ones(neighborhood_size), 'same') - ...
    conv2(double(I_gray), ones(neighborhood_size), 'same').^2 / (neighborhood_size^2);

% Calculate the energy curve
energy_curve = sum(energy_map, 1) / size(energy_map, 1);
exposure = 1 / 256 * cumsum(energy_curve);
exposure = exposure(1);

% Calculate the histograms for the grayscale image
histGray = imhist(I_gray);

% Plot the grayscale image histogram
subplot(321);
plot(histGray, 'k');
title('Grayscale Image Histogram');

% Apply exposure-based energy curve equalization
% Step 2: Compute energy curve for grayscale image
energyCurve1 = cumsum(histGray) / sum(histGray);

% Step 3: Calculate exposure threshold for grayscale image
ET = (256 - 1) * (1 - exposure); % Paper formula

% Step 4: Find the clipping limit for grayscale image
clippingLimit = mean(energyCurve1);

% Step 5: Obtain clipped energy curve for grayscale image
energyCurve1(energyCurve1 > clippingLimit) = clippingLimit;

% Step 6: Divide energy curve into two parts using calculated threshold for grayscale image
energyCurve1(energyCurve1 <= ET) = energyCurve1(energyCurve1 <= ET) / 2;
energyCurve1(energyCurve1 > ET) = (clippingLimit + energyCurve1(energyCurve1 > ET)) / 2;

% Step 7: Generate transformer function for grayscale image
transferFunction1 = sum(energyCurve1, 2);

% Apply the transfer function to the input grayscale image
enhancedImage_gray = histeq(I_gray, transferFunction1);

% Display the enhanced grayscale image
subplot(325);
imshow(imsharpen(uint8(enhancedImage_gray)));
title('Enhanced Grayscale Image');

% Calculate SSIM between input and output images
ssimValue_gray = ssim(I_gray, uint8(enhancedImage_gray));
disp(['SSIM between input and output grayscale images: ' num2str(ssimValue_gray)]);

% Plot the histogram of the enhanced grayscale image
subplot(326);
histEnhanced_gray = imhist(uint8(enhancedImage_gray));
plot(histEnhanced_gray, 'k');
title('Enhanced Grayscale Image Histogram');
