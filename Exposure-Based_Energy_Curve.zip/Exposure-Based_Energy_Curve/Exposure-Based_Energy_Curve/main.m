clc
clear all
close all

% Select the image with low contrast
[J, P] = uigetfile('*.*','Select the image');
I = imread(fullfile(P, J));
subplot(323), imshow(I), title('Input Low Contrast Image ')
L = 256;
img = I;

% Convert to grayscale if necessary
if size(I, 3) == 3
    img = rgb2gray(I);
else
    img = I;
end
% Define the image dimensions
[m, n] = size(img);

% Define the threshold value 'l'
l = 128; % Assuming a threshold value for illustration

% Define the neighborhood size
neighborhood_size = 3; % Assuming a 3x3 neighborhood for illustration

% Initialize the energy curve matrix
energyCurve = zeros(m, n);

% Compute the energy curve for each pixel
for i = 1:m
    for j = 1:n
        energy = 0;
        for u = -1:1
            for v = -1:1
                if i+u > 0 && i+u <= m && j+v > 0 && j+v <= n
                    % Compute B_ij and B_pq based on the condition I_ij > l
                    b_ij = img(i, j) > l;
                    b_pq = img(i+u, j+v) > l;
                    c_ij = 1; % Assuming a constant value for c_ij
                    c_pq = 1; % Assuming a constant value for c_pq
                    energy = energy + b_ij * b_pq + c_ij * c_pq;
                end
            end
        end
        energyCurve(i, j) = energy;
    end
end

% Compute exposure parameter value
L = numel(energyCurve);
weighted_sum = sum(energyCurve(:) .* (0:L-1)');
sum_energy = sum(energyCurve(:));
exposure = 1 / L * (weighted_sum / sum_energy);

% Display the exposure threshold
disp(['Exposure threshold: ', num2str(exposure)]);

% Separate the color channels
if size(I, 3) == 3
    redPlane = I(:,:,1);
    greenPlane = I(:, :, 2);
    bluePlane = I(:, :, 3);
else
    error('Input image is not in RGB format');
end

% Calculate histograms for each channel
histRed = imhist(redPlane);
histGreen = imhist(greenPlane);
histBlue = imhist(bluePlane);

% Plot the histograms
subplot(321);
plot(histRed, 'r');hold on
plot(histGreen, 'g');hold on
plot(histBlue, 'b');hold off
title('Color Image Histogram');
suptitle('Exposure-Based Energy Curve Equalization for Enhancement of Contrast Distorted Images')

% Compute energy curve for each channel
energyCurve1 = zeros(256, 3);
energyCurve2 = zeros(256, 3);
for channel = 1:3
    [counts, ~] = imhist(I(:, :, channel));
    energyCurve = cumsum(counts) / sum(counts);

    % Calculate exposure threshold for each channel
    L = 256; % Number of intensity levels
    ET = round((L - 1) * (1 - exposure)); % Round to the nearest integer

    % Divide energy curve in two parts using calculated threshold for each channel
    energyCurve1(1:ET, channel) = energyCurve(1:ET);
    energyCurve2(ET+1:L-1, channel) = (energyCurve(ET+1:L-1));
    
    % Compute PDF and CDF for lower and upper regions
    PDF_L = energyCurve1(:, channel) / sum(energyCurve1(:, channel));
    PDF_U = energyCurve2(:, channel) / sum(energyCurve2(:, channel));
    CDF_L = cumsum(PDF_L);
    CDF_U = cumsum(PDF_U);
    
    % Generate transformation function for lower curve
    T_L = ET * CDF_L;
    
    % Generate transformation function for upper curve
    T_U = (ET + 1) + (L - (ET + 1)) * CDF_U;
    
    % Final transformation function
    transferFunction = T_L + T_U;
    
    % Display transformation function graph
    subplot(322);
    plot(T_L ,'r'),hold on;
    plot(T_U ,'g'),hold on;
    plot(T_U * 2,'b'),hold off;
    title('Transform Function')

    % Apply the transfer function to the input channel
    enhancedChannel = histeq(imadjust(I(:, :, channel)), transferFunction); % Adjust histogram equalization parameters
    
    % Store the enhanced channel
    enhancedImage(:, :, channel) = enhancedChannel;
end

% Display the enhanced image
subplot(324), imshow(imsharpen(uint8(enhancedImage))); title('Enhanced Image');

% Calculate SSIM between input and output images
ssimValue = ssim(rgb2gray(I), rgb2gray(uint8(enhancedImage)));
disp(['SSIM between input and output images: ' num2str(ssimValue)]);

% Plot histograms of the enhanced image
subplot(326), plot(imhist(uint8(enhancedImage(:,:,1))), 'g'); hold on
plot(imhist(uint8(enhancedImage(:,:,2))), 'r'); hold on
plot(imhist(uint8(enhancedImage(:,:,3))), 'b'); hold off

% Plot histograms of the input image
subplot(325), plot(histRed, 'r'); hold on
plot(histGreen, 'g'); hold on
plot(histBlue, 'b'); hold off
title('Color Image Histogram');


% Convert images to grayscale for MSE calculation
grayInput = rgb2gray(I);
grayEnhanced = rgb2gray(uint8(enhancedImage));

% Calculate Mean Square Error (MSE) between input and enhanced images
diffSquared = (double(grayInput) - double(grayEnhanced)).^2;
MSE = sum(diffSquared(:)) / numel(grayInput);

% Display MSE value
disp(['Mean Square Error (MSE) between input and enhanced images: ' num2str(MSE)]);

% Calculate histogram of the grayscale image
histogram = zeros(256, 1);
for i = 1:m
    for j = 1:n
        intensity = img(i, j) + 1; % Add 1 because MATLAB indices start from 1
        histogram(intensity) = histogram(intensity) + 1;
    end
end

% Normalize the histogram to get probabilities
probabilities = histogram / (m * n);

% Compute entropy using the formula
entropyValue = 0;
for i = 1:numel(probabilities)
    if probabilities(i) > 0
        entropyValue = entropyValue - probabilities(i) * log2(probabilities(i));
    end
end

% Display the entropy value
disp(['Entropy of the grayscale image: ' num2str(entropyValue)]);
